<footer>
    <div class="layout-container">
        <p>Copyright &copy; 2023 Tour and Travels. All rights are reserved.</p>
    </div>

</footer>
    
    <script src="../assets/js/main.js"></script>
</body>
</html>