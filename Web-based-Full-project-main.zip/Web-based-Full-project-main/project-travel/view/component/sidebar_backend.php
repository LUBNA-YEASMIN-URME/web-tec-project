
    <div class="sidebar-menu">
        <ul>
            <li>
                <a href="../view/all_packages.php">All Packages</a>
                <li><a href="../view/add_package.php">Add Package</a></li>
            </li>
            
        </ul>
    </div>
